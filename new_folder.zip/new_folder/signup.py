import pygame
import json

pygame.init()

# Define some colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GRAY = (128, 128, 128)
GREEN = (0, 255, 0)
RED = (255, 0, 0)

# Set the width and height of the screen [width, height]
screen_size = (930, 630)
screen = pygame.display.set_mode(screen_size)

# Set the title of the window
pygame.display.set_caption("Connect 4 - Player Signup")

# Set the font and font size
font = pygame.font.Font(None, 36)

# Set the text boxes and labels
username_box = pygame.Rect(350, 200, 200, 50)
password_box = pygame.Rect(350, 275, 200, 50)
confirm_password_box = pygame.Rect(350, 350, 200, 50)

username_label = font.render("Username:", True, BLACK)
password_label = font.render("Password:", True, BLACK)
confirm_password_label = font.render("Confirm Password:", True, BLACK)

# Set the buttons and labels
register_button = pygame.Rect(350, 425, 100, 50)
register_label = font.render("Register", True, WHITE)

back_button = pygame.Rect(500, 425, 100, 50)
back_label = font.render("Back", True, WHITE)

# Set the initial state of the message label
message = ""
message_label = font.render(message, True, BLACK)

# Set the clock
clock = pygame.time.Clock()

# Run the game loop
done = False

while not done:
    # Check for events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True
        elif event.type == pygame.MOUSEBUTTONDOWN:
            # Check if the user clicked on the register button
            if register_button.collidepoint(event.pos):
                # Get the username and password from the text boxes
                username = pygame.key.name(pygame.KMOD_SHIFT)
                password = ""
                confirm_password = ""

                for char in pygame.key.get_pressed():
                    if char:
                        if char == pygame.K_BACKSPACE:
                            if username_box.collidepoint(event.pos):
                                username = username[:-1]
                            elif password_box.collidepoint(event.pos):
                                password = password[:-1]
                            elif confirm_password_box.collidepoint(event.pos):
                                confirm_password = confirm_password[:-1]
                        elif char == pygame.K_RETURN:
                            pass
                        else:
                            if username_box.collidepoint(event.pos):
                                username += pygame.key.name(char)
                            elif password_box.collidepoint(event.pos):
                                password += pygame.key.name(char)
                            elif confirm_password_box.collidepoint(event.pos):
                                confirm_password += pygame.key.name(char)

                # Check if the password and confirmation match
                if password == confirm_password:
                    # Open the user data file
                    with open("user_data.json", "r") as f:
                        user_data = json.load(f)

                    # Add the new user to the user data file
                    user_data.append({"username": username, "password": password})

                # Save the updated user data file
                with open("user_data.json", "w") as f:
                    json.dump(user_data, f)

                # Set the message to indicate success
                message = "Registration successful!"
                message_label = font.render(message, True, GREEN)
            else:
                # Set the message to indicate a password mismatch
                message = "Passwords do not match."
                message_label = font.render(message, True, RED)

        # Check if the user clicked on the back button
        elif back_button.collidepoint(event.pos):
            done = True

# Fill the screen with white
screen.fill(WHITE)

# Draw the text boxes and labels
pygame.draw.rect(screen, GRAY, username_box, 2)
pygame.draw.rect(screen, GRAY, password_box, 2)
pygame.draw.rect(screen, GRAY, confirm_password_box, 2)

screen.blit(username_label, (200, 215))
screen.blit(password_label, (200, 290))
screen.blit(confirm_password_label, (100, 365))

# Draw the buttons and labels
pygame.draw.rect(screen, GREEN, register_button)
screen.blit(register_label, (register_button.x + 10, register_button.y + 10))

pygame.draw.rect(screen, RED, back_button)
screen.blit(back_label, (back_button.x + 10, back_button.y + 10))

# Draw the message label
screen.blit(message_label, (350, 500))

# Update the screen
pygame.display.flip()

# Set the frame rate
clock.tick(60)
